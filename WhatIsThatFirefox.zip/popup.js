document.getElementById("askBtn").addEventListener("click", async () => {
  const resultElement = document.getElementById("result");
  const spinner = document.getElementById("spinner");

  try {
    const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
    const [injection] = await browser.scripting.executeScript({
      target: { tabId: tab.id },
      func: getSelectedText
    });
    const selectedText = injection?.result;

    resultElement.style.display = "block";
    if (!selectedText) {
      resultElement.innerText = "You must select some text on the page first!";
      return;
    }

    resultElement.innerText = "";
    spinner.style.display = "block";

    const answer = await browser.runtime.sendMessage({
      action: "ask_ai_popup",
      text: selectedText
    });

    spinner.style.display = "none";
    resultElement.innerText = answer.text;
    const modelBadge = document.createElement("div");
    modelBadge.style.cssText = "text-align: right; font-size: 10px; color: #999; margin-top: 8px; font-style: italic;";
    modelBadge.innerText = `— ${answer.model}`;
    resultElement.appendChild(modelBadge);
  } catch (error) {
    spinner.style.display = "none";
    resultElement.style.display = "block";
    resultElement.innerText = "An error occurred: " + error.message;
  }
});

document.getElementById("optionsLink").addEventListener("click", () => {
  void browser.runtime.openOptionsPage();
});

function getSelectedText() {
  return window.getSelection().toString().trim();
}
