let savedKeys = { gemini: "", openai: "", anthropic: "", groq: "", mistral: "", deepseek: "", together: "", openrouter: "", perplexity: "", cohere: "", xai: "", huggingface: "", ollama: "", ai21: "", anyscale: "", deepinfra: "", fireworks: "", novita: "", sambanova: "", upstage: "", alibaba: "", cerebras: "", hyperbolic: "", moonshot: "", nvidia: "", octoai: "" };
let savedModels = { gemini: "", openai: "", anthropic: "", groq: "", mistral: "", deepseek: "", together: "", openrouter: "", perplexity: "", cohere: "", xai: "", huggingface: "", ollama: "", ai21: "", anyscale: "", deepinfra: "", fireworks: "", novita: "", sambanova: "", upstage: "", alibaba: "", cerebras: "", hyperbolic: "", moonshot: "", nvidia: "", octoai: "" };

const MODEL_LIST_ENDPOINTS = {
  openai: "https://api.openai.com/v1/models",
  groq: "https://api.groq.com/openai/v1/models",
  mistral: "https://api.mistral.ai/v1/models",
  deepseek: "https://api.deepseek.com/models",
  together: "https://api.together.xyz/v1/models",
  openrouter: "https://openrouter.ai/api/v1/models",
  xai: "https://api.x.ai/v1/models",
  ai21: "https://api.ai21.com/studio/v1/models",
  deepinfra: "https://api.deepinfra.com/v1/openai/models",
  fireworks: "https://api.fireworks.ai/inference/v1/models",
  novita: "https://api.novita.ai/openai/v1/models",
  sambanova: "https://api.sambanova.ai/v1/models",
  upstage: "https://api.upstage.ai/v1/models",
  alibaba: "https://dashscope-intl.aliyuncs.com/compatible-mode/v1/models",
  cerebras: "https://api.cerebras.ai/v1/models",
  hyperbolic: "https://api.hyperbolic.xyz/v1/models",
  moonshot: "https://api.moonshot.cn/v1/models",
  nvidia: "https://integrate.api.nvidia.com/v1/models",
  huggingface: "https://router.huggingface.co/v1/models"
};

const PREFERRED_MODELS = {
  gemini: "gemini-3.8-flash",
  openai: "gpt-5.6-luna",
  anthropic: "claude-sonnet-5",
  groq: "openai/gpt-oss-20b",
  together: "meta-llama/Llama-3.3-70B-Instruct-Turbo",
  openrouter: "openai/gpt-5.6-luna",
  perplexity: "sonar",
  cohere: "command-a-plus-05-2026",
  xai: "grok-4.20",
  huggingface: "Qwen/Qwen3.8-27B",
  ollama: "llama3.3",
  ai21: "jamba-1.5-large",
  deepinfra: "meta-llama/Llama-3.3-70B-Instruct",
  fireworks: "accounts/fireworks/models/llama-v3p3-70b-instruct",
  novita: "meta-llama/llama-3.3-70b-instruct",
  sambanova: "Meta-Llama-3.3-70B-Instruct",
  upstage: "solar-pro4",
  alibaba: "qwen-plus",
  cerebras: "llama-3.3-70b",
  hyperbolic: "meta-llama/Meta-Llama-3.1-70B-Instruct",
  moonshot: "kimi-k2.5",
  nvidia: "meta/llama-3.3-70b-instruct"
};

// Function to update placeholder and label based on provider
function updateProviderUI() {
  const provider = document.getElementById("provider").value;
  const label = document.getElementById("apiKeyLabel");
  const input = document.getElementById("apiKey");
  const helpBtn = document.getElementById("apiKeyHelpBtn");
  
  let providerName = "Gemini";
  if (provider === "openai") {
    label.innerText = "OpenAI API Key:";
    input.placeholder = "Starts with sk-...";
    providerName = "OpenAI";
  } else if (provider === "anthropic") {
    label.innerText = "Anthropic API Key:";
    input.placeholder = "Starts with sk-ant-...";
    providerName = "Anthropic";
  } else if (provider === "groq") {
    label.innerText = "Groq API Key:";
    input.placeholder = "Starts with gsk_...";
    providerName = "Groq";
  } else if (provider === "mistral") {
    label.innerText = "Mistral API Key:";
    input.placeholder = "Your Mistral API Key...";
    providerName = "Mistral";
  } else if (provider === "deepseek") {
    label.innerText = "DeepSeek API Key:";
    input.placeholder = "Starts with sk-...";
    providerName = "DeepSeek";
  } else if (provider === "together") {
    label.innerText = "Together AI API Key:";
    input.placeholder = "Your Together API Key...";
    providerName = "Together";
  } else if (provider === "openrouter") {
    label.innerText = "OpenRouter API Key:";
    input.placeholder = "Starts with sk-or-...";
    providerName = "OpenRouter";
  } else if (provider === "perplexity") {
    label.innerText = "Perplexity API Key:";
    input.placeholder = "Starts with pplx-...";
    providerName = "Perplexity";
  } else if (provider === "cohere") {
    label.innerText = "Cohere API Key:";
    input.placeholder = "Your Cohere API Key...";
    providerName = "Cohere";
  } else if (provider === "xai") {
    label.innerText = "xAI (Grok) API Key:";
    input.placeholder = "Starts with xai-...";
    providerName = "xAI";
  } else if (provider === "huggingface") {
    label.innerText = "Hugging Face Access Token:";
    input.placeholder = "Starts with hf_...";
    providerName = "HuggingFace";
  } else if (provider === "ai21") {
    label.innerText = "AI21 Labs API Key:";
    input.placeholder = "Starts with ...";
    providerName = "AI21 Labs";
  } else if (provider === "deepinfra") {
    label.innerText = "DeepInfra API Key:";
    input.placeholder = "Your DeepInfra API Key...";
    providerName = "DeepInfra";
  } else if (provider === "fireworks") {
    label.innerText = "Fireworks AI API Key:";
    input.placeholder = "Starts with fw_...";
    providerName = "Fireworks AI";
  } else if (provider === "novita") {
    label.innerText = "Novita AI API Key:";
    input.placeholder = "Your Novita API Key...";
    providerName = "Novita AI";
  } else if (provider === "sambanova") {
    label.innerText = "SambaNova API Key:";
    input.placeholder = "Your SambaNova API Key...";
    providerName = "SambaNova";
  } else if (provider === "upstage") {
    label.innerText = "Upstage API Key:";
    input.placeholder = "Starts with up_...";
    providerName = "Upstage";
  } else if (provider === "alibaba") {
    label.innerText = "Alibaba Cloud API Key:";
    input.placeholder = "Starts with sk-...";
    providerName = "Alibaba Cloud";
  } else if (provider === "cerebras") {
    label.innerText = "Cerebras API Key:";
    input.placeholder = "Your Cerebras API Key...";
    providerName = "Cerebras";
  } else if (provider === "hyperbolic") {
    label.innerText = "Hyperbolic API Key:";
    input.placeholder = "Your Hyperbolic API Key...";
    providerName = "Hyperbolic";
  } else if (provider === "moonshot") {
    label.innerText = "Moonshot AI API Key:";
    input.placeholder = "Starts with sk-...";
    providerName = "Moonshot AI";
  } else if (provider === "nvidia") {
    label.innerText = "NVIDIA NIM API Key:";
    input.placeholder = "Starts with nvapi-...";
    providerName = "NVIDIA NIM";
  } else if (provider === "ollama") {
    label.innerText = "Ollama requires no API Key:";
    input.placeholder = "Ensure Ollama is running on localhost:11434";
    providerName = "Ollama";
  } else {
    label.innerText = "Gemini API Key:";
    input.placeholder = "Starts with AIzaSy...";
    providerName = "Gemini";
  }
  
  input.value = savedKeys[provider] || "";
  input.disabled = (provider === "ollama");
  
  helpBtn.innerText = `How can I get an ${providerName} API key?`;
  if (providerName === "Gemini" || providerName === "Groq" || providerName === "Mistral" || providerName === "Together" || providerName === "DeepSeek" || providerName === "Perplexity" || providerName === "Cohere" || providerName === "HuggingFace" || providerName === "DeepInfra" || providerName === "Novita AI" || providerName === "SambaNova" || providerName === "Hyperbolic" || providerName === "NVIDIA NIM" || providerName === "Cerebras" || providerName === "Alibaba Cloud" || providerName === "Moonshot AI") {
    helpBtn.innerText = `How can I get a ${providerName} API key?`;
  }
  
  if (providerName === "Ollama") {
    helpBtn.innerText = "Download Ollama";
    helpBtn.onclick = () => window.open("https://ollama.com", "_blank");
  } else {
    helpBtn.onclick = () => {
      window.open(`https://www.google.com/search?q=How+can+I+get+a+${providerName}+API+key`, "_blank");
    };
  }
  
  // Reset model dropdown
  currentFetchedModels = [];
  document.getElementById("modelInput").value = savedModels[provider] || "";
}

let currentFetchedModels = [];

function renderCustomDropdown(filterText) {
  const dropdown = document.getElementById("modelDropdown");
  const modelInput = document.getElementById("modelInput");
  const provider = document.getElementById("provider").value;
  
  dropdown.replaceChildren();
  
  let items = currentFetchedModels;
  if (items.length === 0 && savedModels[provider]) {
    items = [savedModels[provider]];
  }

  const filtered = items.filter(m => m.toLowerCase().includes(filterText.toLowerCase()));
  
  if (filtered.length === 0) {
    const emptyState = document.createElement("div");
    emptyState.textContent = "No models found. Click Fetch Models.";
    emptyState.style.cssText = "padding: 10px; color: #999; font-size: 14px;";
    dropdown.appendChild(emptyState);
    return;
  }
  
  filtered.forEach(m => {
    const div = document.createElement("div");
    div.innerText = m;
    div.style.cssText = "padding: 10px; cursor: pointer; border-bottom: 1px solid #eee; font-size: 14px; color: #333;";
    div.onmouseenter = () => div.style.backgroundColor = "#f0f0f0";
    div.onmouseleave = () => div.style.backgroundColor = "transparent";
    div.onclick = () => {
      modelInput.value = m;
      dropdown.style.display = "none";
      savedModels[provider] = m;
      autoSave();
    };
    dropdown.appendChild(div);
  });
}

document.getElementById("modelInput").addEventListener("focus", () => {
  const provider = document.getElementById("provider").value;
  const apiKey = document.getElementById("apiKey").value.trim();
  if (currentFetchedModels.length === 0 && (apiKey !== "" || provider === "ollama")) {
    fetchModelsLogic(true);
  }
  document.getElementById("modelDropdown").style.display = "block";
  renderCustomDropdown(document.getElementById("modelInput").value.trim());
});

document.getElementById("modelInput").addEventListener("input", (e) => {
  document.getElementById("modelDropdown").style.display = "block";
  renderCustomDropdown(e.target.value.trim());
  const provider = document.getElementById("provider").value;
  savedModels[provider] = e.target.value.trim();
  autoSave();
});

document.addEventListener("click", (e) => {
  const modelInput = document.getElementById("modelInput");
  const dropdown = document.getElementById("modelDropdown");
  if (e.target !== modelInput && !dropdown.contains(e.target)) {
    dropdown.style.display = "none";
  }
});

// Save input immediately to memory when typing
let saveTimeout;
document.getElementById("apiKey").addEventListener("input", (e) => {
  const provider = document.getElementById("provider").value;
  savedKeys[provider] = e.target.value.trim();
  
  clearTimeout(saveTimeout);
  saveTimeout = setTimeout(() => {
    autoSave();
    if (e.target.value.trim() !== "" || provider === "ollama") {
      fetchModelsLogic(true);
    }
  }, 500);
});

// Listen for provider changes
document.getElementById("provider").addEventListener("change", () => {
  updateProviderUI();
  autoSave();
  
  const apiKey = document.getElementById("apiKey").value.trim();
  const providerVal = document.getElementById("provider").value;
  if (apiKey !== "" || providerVal === "ollama") {
    fetchModelsLogic(true);
  }
});

// Fetch Models Logic
async function fetchModelsLogic(silent = false) {
  const provider = document.getElementById("provider").value;
  const apiKey = document.getElementById("apiKey").value.trim();
  const fetchBtn = document.getElementById("fetchModelsBtn");
  
  if (!apiKey && provider !== "ollama") {
    if (!silent) alert("Please enter an API Key first.");
    return;
  }
  
  fetchBtn.innerText = "Loading...";
  
  try {
    let models = [];
    if (provider === "ollama") {
      const data = await fetchJson("http://localhost:11434/api/tags");
      models = (data.models || []).map((model) => model.name).filter(Boolean);
    } else if (MODEL_LIST_ENDPOINTS[provider]) {
      const headers = { "Authorization": `Bearer ${apiKey}` };
      if (provider === "huggingface") headers["Accept"] = "application/json";
      const data = await fetchJson(MODEL_LIST_ENDPOINTS[provider], { headers });
      models = extractModelIds(data, provider);
    } else if (provider === "gemini") {
      const data = await fetchJson("https://generativelanguage.googleapis.com/v1beta/models", {
        headers: { "x-goog-api-key": apiKey }
      });
      models = (data.models || [])
        .filter((model) => (model.supportedGenerationMethods || []).includes("generateContent"))
        .map((model) => model.name.replace(/^models\//, ""));
    } else if (provider === "anthropic") {
      const data = await fetchJson("https://api.anthropic.com/v1/models", {
        headers: { "x-api-key": apiKey, "anthropic-version": "2023-06-01" }
      });
      models = extractModelIds(data, provider);
    } else if (provider === "perplexity") {
      models = ["sonar", "sonar-pro", "sonar-reasoning", "sonar-reasoning-pro", "sonar-deep-research", "r1-1776"];
    } else if (provider === "cohere") {
      const data = await fetchJson("https://api.cohere.com/v1/models", {
        headers: { "Authorization": `Bearer ${apiKey}` }
      });
      models = (data.models || [])
        .filter((model) => model.is_deprecated !== true && (model.endpoints || []).includes("chat"))
        .map((model) => model.name);
    }

    models = [...new Set(models)].filter(Boolean).sort((a, b) => a.localeCompare(b));
    if (!models.length) throw new Error("No compatible chat models were returned for this API key.");
    currentFetchedModels = models;

    const modelInput = document.getElementById("modelInput");
    if (!modelInput.value.trim()) {
      const preferred = PREFERRED_MODELS[provider];
      const autoModel = models.find((model) => model === preferred) || models[0];
      modelInput.value = autoModel;
      savedModels[provider] = autoModel;
      autoSave();
    }
    renderCustomDropdown(document.getElementById("modelInput").value.trim());
    if (document.activeElement === document.getElementById("modelInput")) {
      document.getElementById("modelDropdown").style.display = "block";
    }
  } catch (error) {
    if (!silent) alert("Error fetching models: " + error.message);
  } finally {
    fetchBtn.innerText = "Fetch Models";
  }
}

async function fetchJson(url, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    const text = await response.text();
    let data = {};
    try { data = text ? JSON.parse(text) : {}; } catch { data = { message: text }; }
    if (!response.ok) {
      throw new Error(data.error?.message || data.message || data.detail || `HTTP ${response.status}`);
    }
    return data;
  } catch (error) {
    if (error.name === "AbortError") throw new Error("The model list request timed out.");
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

function extractModelIds(data, provider) {
  const entries = Array.isArray(data) ? data : (data.data || data.models || data.results || []);
  return entries.filter((model) => {
    const id = typeof model === "string" ? model : (model.id || model.name || model.model || model.model_id);
    if (!id || model.active === false || model.is_deprecated === true || model.deprecated === true) return false;
    if (provider === "cohere") return (model.endpoints || []).includes("chat");
    if (provider === "huggingface") return true; // /v1/models only returns chat-completion models.

    const type = String(model.type || model.task || model.object || "").toLowerCase();
    if (type && !["model", "chat", "chat_completion", "chat-completion", "conversational", "text-generation"].includes(type)) {
      if (!/chat|conversational|text-generation/.test(type)) return false;
    }
    if (Array.isArray(model.endpoints) && model.endpoints.length && !model.endpoints.includes("chat")) return false;
    if (model.capabilities) {
      const chatFlags = [model.capabilities.chat, model.capabilities.chat_completion, model.capabilities.completion_chat]
        .filter((value) => typeof value === "boolean");
      if (chatFlags.length && !chatFlags.some(Boolean)) return false;
    }
    if (/deprecated|retired|disabled/i.test(String(model.status || model.lifecycle || ""))) return false;
    return !/(embed|embedding|rerank|moderation|whisper|transcri|text-to-speech|tts|dall-e|image|audio|guard|classif)/i.test(id);
  }).map((model) => typeof model === "string" ? model : (model.id || model.name || model.model || model.model_id));
}

document.getElementById("fetchModelsBtn").addEventListener("click", () => fetchModelsLogic(false));

// If a key or language was previously saved, populate the inputs when the page loads
document.addEventListener("DOMContentLoaded", async () => {
  const result = await browser.storage.local.get([
    "geminiApiKey", "openaiApiKey", "anthropicApiKey", "groqApiKey", "mistralApiKey", "deepseekApiKey", "togetherApiKey", "openrouterApiKey", "perplexityApiKey", "cohereApiKey", "xaiApiKey", "huggingfaceApiKey", "ollamaApiKey", "ai21ApiKey", "anyscaleApiKey", "deepinfraApiKey", "fireworksApiKey", "novitaApiKey", "sambanovaApiKey", "upstageApiKey", "alibabaApiKey", "cerebrasApiKey", "hyperbolicApiKey", "moonshotApiKey", "nvidiaApiKey", "octoaiApiKey",
    "geminiModel", "openaiModel", "anthropicModel", "groqModel", "mistralModel", "deepseekModel", "togetherModel", "openrouterModel", "perplexityModel", "cohereModel", "xaiModel", "huggingfaceModel", "ollamaModel", "ai21Model", "anyscaleModel", "deepinfraModel", "fireworksModel", "novitaModel", "sambanovaModel", "upstageModel", "alibabaModel", "cerebrasModel", "hyperbolicModel", "moonshotModel", "nvidiaModel", "octoaiModel",
    "language", "provider", "quickIconEnabled"
  ]);
    savedKeys.gemini = result.geminiApiKey || "";
    savedKeys.openai = result.openaiApiKey || "";
    savedKeys.anthropic = result.anthropicApiKey || "";
    savedKeys.groq = result.groqApiKey || "";
    savedKeys.mistral = result.mistralApiKey || "";
    savedKeys.deepseek = result.deepseekApiKey || "";
    savedKeys.together = result.togetherApiKey || "";
    savedKeys.openrouter = result.openrouterApiKey || "";
    savedKeys.perplexity = result.perplexityApiKey || "";
    savedKeys.cohere = result.cohereApiKey || "";
    savedKeys.xai = result.xaiApiKey || "";
    savedKeys.huggingface = result.huggingfaceApiKey || "";
    savedKeys.ollama = result.ollamaApiKey || "";
    savedKeys.ai21 = result.ai21ApiKey || "";
    savedKeys.anyscale = result.anyscaleApiKey || "";
    savedKeys.deepinfra = result.deepinfraApiKey || "";
    savedKeys.fireworks = result.fireworksApiKey || "";
    savedKeys.novita = result.novitaApiKey || "";
    savedKeys.sambanova = result.sambanovaApiKey || "";
    savedKeys.upstage = result.upstageApiKey || "";
    savedKeys.alibaba = result.alibabaApiKey || "";
    savedKeys.cerebras = result.cerebrasApiKey || "";
    savedKeys.hyperbolic = result.hyperbolicApiKey || "";
    savedKeys.moonshot = result.moonshotApiKey || "";
    savedKeys.nvidia = result.nvidiaApiKey || "";
    savedKeys.octoai = result.octoaiApiKey || "";
    
    savedModels.gemini = result.geminiModel || "";
    savedModels.openai = result.openaiModel || "";
    savedModels.anthropic = result.anthropicModel || "";
    savedModels.groq = result.groqModel || "";
    savedModels.mistral = result.mistralModel || "";
    savedModels.deepseek = result.deepseekModel || "";
    savedModels.together = result.togetherModel || "";
    savedModels.openrouter = result.openrouterModel || "";
    savedModels.perplexity = result.perplexityModel || "";
    savedModels.cohere = result.cohereModel || "";
    savedModels.xai = result.xaiModel || "";
    savedModels.huggingface = result.huggingfaceModel || "";
    savedModels.ollama = result.ollamaModel || "";
    savedModels.ai21 = result.ai21Model || "";
    savedModels.anyscale = result.anyscaleModel || "";
    savedModels.deepinfra = result.deepinfraModel || "";
    savedModels.fireworks = result.fireworksModel || "";
    savedModels.novita = result.novitaModel || "";
    savedModels.sambanova = result.sambanovaModel || "";
    savedModels.upstage = result.upstageModel || "";
    savedModels.alibaba = result.alibabaModel || "";
    savedModels.cerebras = result.cerebrasModel || "";
    savedModels.hyperbolic = result.hyperbolicModel || "";
    savedModels.moonshot = result.moonshotModel || "";
    savedModels.nvidia = result.nvidiaModel || "";
    savedModels.octoai = result.octoaiModel || "";
    
    if (result.language) {
      document.getElementById("language").value = result.language;
    }
    const availableProviders = Array.from(document.getElementById("provider").options).map((option) => option.value);
    if (result.provider && availableProviders.includes(result.provider)) {
      document.getElementById("provider").value = result.provider;
    } else if (result.provider) {
      document.getElementById("provider").value = "gemini";
      document.getElementById("status").textContent = "Your previously selected provider is no longer available here. Choose a supported provider and save its key.";
    }
    
    document.getElementById("enableQuickIcon").checked = result.quickIconEnabled !== false;
    
    updateProviderUI();
    
    const apiKey = document.getElementById("apiKey").value.trim();
    const providerVal = document.getElementById("provider").value;
    if (apiKey !== "" || providerVal === "ollama") {
      fetchModelsLogic(true);
    }
});

// Auto save function
let statusTimeout;
let statusInterval;

function autoSave() {
  const provider = document.getElementById("provider").value;
  savedKeys[provider] = document.getElementById("apiKey").value.trim();
  savedModels[provider] = document.getElementById("modelInput").value.trim();
  const language = document.getElementById("language").value;
  const quickIconEnabled = document.getElementById("enableQuickIcon").checked;
  
  browser.storage.local.set({ 
    geminiApiKey: savedKeys.gemini, 
    openaiApiKey: savedKeys.openai, 
    anthropicApiKey: savedKeys.anthropic,
    groqApiKey: savedKeys.groq,
    mistralApiKey: savedKeys.mistral,
    deepseekApiKey: savedKeys.deepseek,
    togetherApiKey: savedKeys.together,
    openrouterApiKey: savedKeys.openrouter,
    perplexityApiKey: savedKeys.perplexity,
    cohereApiKey: savedKeys.cohere,
    xaiApiKey: savedKeys.xai,
    huggingfaceApiKey: savedKeys.huggingface,
    ollamaApiKey: savedKeys.ollama,
    ai21ApiKey: savedKeys.ai21,
    anyscaleApiKey: savedKeys.anyscale,
    deepinfraApiKey: savedKeys.deepinfra,
    fireworksApiKey: savedKeys.fireworks,
    novitaApiKey: savedKeys.novita,
    sambanovaApiKey: savedKeys.sambanova,
    upstageApiKey: savedKeys.upstage,
    alibabaApiKey: savedKeys.alibaba,
    cerebrasApiKey: savedKeys.cerebras,
    hyperbolicApiKey: savedKeys.hyperbolic,
    moonshotApiKey: savedKeys.moonshot,
    nvidiaApiKey: savedKeys.nvidia,
    octoaiApiKey: savedKeys.octoai,
    geminiModel: savedModels.gemini,
    openaiModel: savedModels.openai,
    anthropicModel: savedModels.anthropic,
    groqModel: savedModels.groq,
    mistralModel: savedModels.mistral,
    deepseekModel: savedModels.deepseek,
    togetherModel: savedModels.together,
    openrouterModel: savedModels.openrouter,
    perplexityModel: savedModels.perplexity,
    cohereModel: savedModels.cohere,
    xaiModel: savedModels.xai,
    huggingfaceModel: savedModels.huggingface,
    ollamaModel: savedModels.ollama,
    ai21Model: savedModels.ai21,
    anyscaleModel: savedModels.anyscale,
    deepinfraModel: savedModels.deepinfra,
    fireworksModel: savedModels.fireworks,
    novitaModel: savedModels.novita,
    sambanovaModel: savedModels.sambanova,
    upstageModel: savedModels.upstage,
    alibabaModel: savedModels.alibaba,
    cerebrasModel: savedModels.cerebras,
    hyperbolicModel: savedModels.hyperbolic,
    moonshotModel: savedModels.moonshot,
    nvidiaModel: savedModels.nvidia,
    octoaiModel: savedModels.octoai,
    language: language, 
    provider: provider,
    quickIconEnabled: quickIconEnabled
  }).then(() => {
    const status = document.getElementById("status");
    status.innerText = "Saved";
    status.style.opacity = "1";
    
    clearTimeout(statusTimeout);
    clearInterval(statusInterval);
    
    // Fade out effect
    statusTimeout = setTimeout(() => {
      let opacity = 1;
      statusInterval = setInterval(() => {
        if (opacity <= 0.1) {
          clearInterval(statusInterval);
          status.textContent = "";
          status.style.opacity = "1";
        }
        status.style.opacity = opacity;
        opacity -= Math.max(opacity * 0.1, 0.05);
      }, 50);
    }, 1500);
  }).catch((error) => {
    const status = document.getElementById("status");
    status.innerText = `Could not save settings: ${error.message}`;
    status.style.opacity = "1";
  });
}

document.getElementById("language").addEventListener("change", autoSave);
document.getElementById("enableQuickIcon").addEventListener("change", autoSave);
