# What is that? — Chrome and Firefox

This folder can be loaded as an unpacked extension in Chrome 121 or newer, or as a temporary add-on in Firefox 142 or newer. The Firefox minimum uses Firefox's built-in consent flow for the extension's network data disclosures on desktop and Android.

## Firefox

1. Open `about:debugging` in Firefox.
2. Select **This Firefox**.
3. Choose **Load Temporary Add-on…** and select this folder's `manifest.json`.

The temporary add-on is removed when Firefox closes. For AMO distribution, keep the Gecko ID stable and complete the store listing and privacy disclosures. See [privacy-policy.html](privacy-policy.html).

## Chrome

Open `chrome://extensions`, enable **Developer mode**, and choose **Load unpacked** to select this folder.

## Polyfill

`browser-polyfill.js` is Mozilla `webextension-polyfill` version 0.12.0. Firefox provides `browser.*` natively; the file is a no-op there and supplies the Promise-based API where Chrome needs it. Its MPL-2.0 license is included as `WEBEXTENSION-POLYFILL-LICENSE.txt`.

## AI models and privacy

The settings page fetches the active chat models supported by the selected provider's API and lets you choose a model ID. The request adapters use the provider's current chat API format; OpenAI uses the Responses API, Cohere uses Chat API v2, and Ollama uses its local `/api/chat` endpoint. Model availability depends on your provider account, region, and plan.

When you request an explanation, the selected text and provider API key go directly from your browser to the provider you selected. The extension stores the key in the browser's local extension storage. For full details, see [privacy-policy.html](privacy-policy.html).
